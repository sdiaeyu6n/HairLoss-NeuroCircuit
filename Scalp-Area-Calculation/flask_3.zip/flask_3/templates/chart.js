{/* <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.5.0/Chart.min.js"></script>
<canvas id="myChart" width="400" height="400"></canvas> */}

  new Chart(document.getElementById("myCanvas"), {
  type: 'line',
  data: {
    labels: mon_unique,
    datasets: [{
        data: ab_val,
        label: "Alberta",
        borderColor: "#3e95cd",
        fill: false
      }, {
        data: BC_val,
        label: "BC",
        borderColor: "#8e5ea2",
        fill: false
      }, {
        data: mb_val,
        label: "Manitoba",
        borderColor: "#3cba9f",
        fill: false
      }, {
        data: nb_val,
        label: "New Brunswick",
        borderColor: "#e8c3b9",
        fill: false
      }, {
        data: nl_val,
        label: "NL",
        borderColor: "#c45850",
        fill: false
      }
    ]
  },
  options: {
    title: {
      display: true,
      text: 'Positive Cases of COVID in provinces of Canada'
    },
    hover: {
     mode: 'index',
     intersect: true
    },
  }
});