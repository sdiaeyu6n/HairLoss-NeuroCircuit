from flask import Flask, flash, redirect, render_template, request, url_for
from flask_sqlalchemy import SQLAlchemy
import logging

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///users.sqlite3'
app.config['SECRET_KEY'] = "abcdefg anything"

db = SQLAlchemy(app)

class users(db.Model):
    id = db.Column(db.Integer, primary_key = True, unique = True, autoincrement = True)
    s_id = db.Column(db.String(30))
    s_name = db.Column(db.String(100))
    s_date = db.Column(db.String(100))
    # s_output = db.Column(db.Float(100))
    

    def __init__(self, id, name, date):
        self.s_id = id
        self.s_name = name
        self.s_date = date
        # self.s_output = output
        
        
@app.route('/')
def index():
    return render_template('index.html') 

@app.route("/chart")
def home():
    return render_template("home.html")

@app.route('/add_new', methods = ['GET', 'POST'])
def add_new():
    if request.method == 'POST':
        if not request.form['s_id'] or not request.form['s_name'] or not request.form['s_date']:
            flash('모든 정보를 입력해주세요.', 'error')
        else:
            user = users(request.form['s_id'],request.form['s_name'],request.form['s_date'])
            db.session.add(user)
            db.session.commit()

            flash('기록이 저장되었습니다.')
            return redirect(url_for('show_users'))
    return render_template('add_new.html')

@app.route('/show_users')
def show_users():
    return render_template('show_list.html', users = users.query.all())

@app.route('/delete/<user_id>')
def delete(user_id):
    user = users.query.filter_by(id = user_id).first()
    db.session.delete(user)
    db.session.commit()
    return render_template('show_list.html', users = users.query.all() )

@app.route('/update/<user_id>', methods = ['GET', 'POST'])
def update(user_id):
    update_user = users.query.filter_by(id = user_id).first()
    if request.method == 'POST':
        if not request.form['s_id'] or not request.form['s_name'] or not request.form['s_date']:
            flash('모든 정보를 입력해주세요.', 'error')
        else:
            update_user.s_id = request.form['s_id']
            update_user.s_name = request.form['s_name']
            update_user.s_name = request.form['s_date']
            db.session.commit()

            flash('기록이 저장되었습니다.')
            return redirect(url_for('show_users'))
    return render_template('edit.html', user = update_user)

if __name__ == '__main__':
    db.create_all()
    app.run(debug=True)